import React, { createContext, useContext, useEffect, useState } from 'react';
import { UserProfile } from '../types';
import { Storage } from '../lib/storage';

const STORAGE_KEY = 'tasknest_user';

const INITIAL_USER: UserProfile = {
  name: '',
  age: '',
  weight: '',
  height: '',
  onboarded: false,
};

interface UserContextType {
  user: UserProfile;
  loading: boolean;
  updateProfile: (updates: Partial<UserProfile>) => void;
  completeOnboarding: (name: string, age: string, weight: string, height: string) => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export function UserProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<UserProfile>(INITIAL_USER);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadUser = async () => {
      const data = await Storage.getItem(STORAGE_KEY);
      if (data) {
        setUser(JSON.parse(data));
      }
      setLoading(false);
    };
    loadUser();
  }, []);

  const saveUser = async (newUser: UserProfile) => {
    setUser(newUser);
    await Storage.setItem(STORAGE_KEY, JSON.stringify(newUser));
  };

  const updateProfile = (updates: Partial<UserProfile>) => {
    const newUser = { ...user, ...updates };
    saveUser(newUser);
  };

  const completeOnboarding = (name: string, age: string, weight: string, height: string) => {
    saveUser({
      name,
      age,
      weight,
      height,
      onboarded: true,
    });
  };

  return (
    <UserContext.Provider value={{ user, loading, updateProfile, completeOnboarding }}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error('useUser must be used within a UserProvider');
  }
  return context;
}
