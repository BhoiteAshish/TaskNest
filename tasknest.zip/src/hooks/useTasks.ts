import { useState, useEffect } from 'react';
import { Task } from '../types';
import { Storage } from '../lib/storage';

const STORAGE_KEY = 'tasknest_tasks';

export function useTasks() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadTasks = async () => {
      const data = await Storage.getItem(STORAGE_KEY);
      if (data) {
        setTasks(JSON.parse(data));
      }
      setLoading(false);
    };
    loadTasks();
  }, []);

  const saveTasks = async (newTasks: Task[]) => {
    setTasks(newTasks);
    await Storage.setItem(STORAGE_KEY, JSON.stringify(newTasks));
  };

  const addTask = (title: string, time: string, category: Task['category']) => {
    const newTask: Task = {
      id: crypto.randomUUID(),
      title,
      time,
      category,
      completed: false,
      createdAt: Date.now(),
    };
    saveTasks([...tasks, newTask]);
  };

  const toggleTask = (id: string) => {
    const newTasks = tasks.map(t => 
      t.id === id ? { ...t, completed: !t.completed } : t
    );
    saveTasks(newTasks);
  };

  const deleteTask = (id: string) => {
    saveTasks(tasks.filter(t => t.id !== id));
  };

  const tasksCompletedToday = tasks.filter(t => t.completed).length;
  const totalTasks = tasks.length;
  const allTasksCompleted = totalTasks > 0 && tasksCompletedToday === totalTasks;

  return {
    tasks,
    loading,
    addTask,
    toggleTask,
    deleteTask,
    tasksCompletedToday,
    totalTasks,
    allTasksCompleted,
  };
}
