import { useState, useEffect } from 'react';
import { Habit } from '../types';
import { Storage } from '../lib/storage';

const STORAGE_KEY = 'tasknest_habits';

const DEFAULT_HABITS: Habit[] = [
  { id: '1', name: 'Drink Water', target: 8, current: 0, category: 'Health', completed: false },
  { id: '2', name: 'Exercise', target: 1, current: 0, category: 'Fitness', completed: false },
  { id: '3', name: 'Reading', target: 1, current: 0, category: 'Education', completed: false },
  { id: '4', name: 'Sleep Early', target: 1, current: 0, category: 'Health', completed: false },
];

export function useHabits() {
  const [habits, setHabits] = useState<Habit[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadHabits = async () => {
      const data = await Storage.getItem(STORAGE_KEY);
      if (data) {
        setHabits(JSON.parse(data));
      } else {
        setHabits(DEFAULT_HABITS);
      }
      setLoading(false);
    };
    loadHabits();
  }, []);

  const saveHabits = async (newHabits: Habit[]) => {
    setHabits(newHabits);
    await Storage.setItem(STORAGE_KEY, JSON.stringify(newHabits));
  };

  const incrementHabit = (id: string) => {
    const newHabits = habits.map(h => {
      if (h.id === id) {
        const nextCount = Math.min(h.current + 1, h.target);
        return {
          ...h,
          current: nextCount,
          completed: nextCount === h.target
        };
      }
      return h;
    });
    saveHabits(newHabits);
  };

  const resetHabits = () => {
    saveHabits(habits.map(h => ({ ...h, current: 0, completed: false })));
  };

  const addHabit = (name: string, target: number, category: string) => {
    const newHabit: Habit = {
      id: crypto.randomUUID(),
      name,
      target,
      current: 0,
      category,
      completed: false
    };
    saveHabits([...habits, newHabit]);
  };

  const deleteHabit = (id: string) => {
    saveHabits(habits.filter(h => h.id !== id));
  };

  return {
    habits,
    loading,
    incrementHabit,
    resetHabits,
    addHabit,
    deleteHabit,
  };
}
