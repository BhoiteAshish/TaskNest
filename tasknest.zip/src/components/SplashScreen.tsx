import { motion } from 'motion/react';
import { Bird } from 'lucide-react';

export default function SplashScreen() {
  return (
    <div className="fixed inset-0 z-[100] bg-gradient-to-br from-blue-600 to-indigo-700 flex flex-col items-center justify-center text-white">
      <motion.div
        initial={{ scale: 0.5, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ 
          type: "spring",
          stiffness: 260,
          damping: 20,
          delay: 0.2
        }}
        className="bg-white/10 p-8 rounded-[3rem] backdrop-blur-xl border border-white/20 shadow-2xl mb-8"
      >
        <Bird size={80} className="text-white drop-shadow-xl" strokeWidth={1.5} />
      </motion.div>
      
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.6 }}
        className="text-center"
      >
        <h1 className="text-4xl font-black tracking-tighter mb-1">TaskNest</h1>
        <div className="h-1 w-12 bg-white/30 mx-auto rounded-full mb-4" />
        <p className="text-blue-100 font-bold uppercase tracking-[0.3em] text-[10px]">Your Daily Haven</p>
      </motion.div>

      <motion.div 
        className="absolute bottom-12 flex space-x-2"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1 }}
      >
         {[0, 1, 2].map((i) => (
           <motion.div
             key={i}
             className="w-2 h-2 bg-white/40 rounded-full"
             animate={{ opacity: [0.3, 1, 0.3], scale: [0.8, 1.2, 0.8] }}
             transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.2 }}
           />
         ))}
      </motion.div>
    </div>
  );
}
