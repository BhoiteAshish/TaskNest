import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, CheckSquare, Activity, Settings } from 'lucide-react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex flex-col min-h-screen bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100 transition-colors duration-300">
      {/* Mobile Top Bar / Safe Area */}
      <div className="h-4 bg-transparent" />
      
      <main className="flex-1 pb-24 overflow-x-hidden">
        <div className="max-w-md mx-auto px-4 h-full">
          {children}
        </div>
      </main>

      {/* Bottom Tab Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-50">
        <div className="max-w-md mx-auto px-4 pb-8 pt-2">
          <div className="bg-white/80 dark:bg-neutral-900/80 backdrop-blur-xl border border-neutral-200 dark:border-neutral-800 rounded-3xl p-2 flex justify-around items-center shadow-lg shadow-neutral-200/50 dark:shadow-black/50">
            <TabItem to="/" icon={<Home size={24} />} label="Home" />
            <TabItem to="/tasks" icon={<CheckSquare size={24} />} label="Tasks" />
            <TabItem to="/habits" icon={<Activity size={24} />} label="Habits" />
            <TabItem to="/settings" icon={<Settings size={24} />} label="Settings" />
          </div>
        </div>
      </nav>
    </div>
  );
}

function TabItem({ to, icon, label }: { to: string; icon: React.ReactNode; label: string }) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) => 
        cn(
          "relative flex flex-col items-center justify-center py-2 px-4 rounded-2xl transition-all duration-300",
          isActive 
            ? "text-blue-600 dark:text-blue-400" 
            : "text-neutral-400 dark:text-neutral-500 hover:text-neutral-600 dark:hover:text-neutral-300"
        )
      }
    >
      {({ isActive }) => (
        <>
          {isActive && (
            <motion.div
              layoutId="navTab"
              className="absolute inset-0 bg-blue-50 dark:bg-blue-900/20 rounded-2xl -z-10"
              transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
            />
          )}
          {icon}
          <span className="text-[10px] font-medium mt-1">{label}</span>
        </>
      )}
    </NavLink>
  );
}
