import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useUser } from '../hooks/useUser';
import { User, Target, Scale, Ruler, ArrowRight } from 'lucide-react';

export default function Onboarding() {
  const { completeOnboarding } = useUser();
  const [step, setStep] = useState(1);
  
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [weight, setWeight] = useState('');
  const [height, setHeight] = useState('');

  const nextStep = () => {
    if (step < 4) setStep(step + 1);
    else completeOnboarding(name, age, weight, height);
  };

  const steps = [
    {
      title: "What's your name?",
      subtitle: "Let's personalize your experience.",
      icon: <User size={40} className="text-blue-500" />,
      input: (
        <input
          autoFocus
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Enter your name"
          className="w-full bg-neutral-100 dark:bg-neutral-800 border-none rounded-2xl p-4 focus:ring-2 focus:ring-blue-500 outline-none text-center text-xl font-bold"
        />
      ),
      disabled: !name.trim()
    },
    {
      title: "How old are you?",
      subtitle: "To help customize your goals.",
      icon: <Target size={40} className="text-indigo-500" />,
      input: (
        <input
          autoFocus
          type="number"
          value={age}
          onChange={(e) => setAge(e.target.value)}
          placeholder="Age"
          className="w-full bg-neutral-100 dark:bg-neutral-800 border-none rounded-2xl p-4 focus:ring-2 focus:ring-blue-500 outline-none text-center text-xl font-bold"
        />
      ),
      disabled: !age
    },
    {
      title: "Your Weight",
      subtitle: "Used for health habit tracking (kg).",
      icon: <Scale size={40} className="text-green-500" />,
      input: (
        <input
          autoFocus
          type="number"
          value={weight}
          onChange={(e) => setWeight(e.target.value)}
          placeholder="Weight in kg"
          className="w-full bg-neutral-100 dark:bg-neutral-800 border-none rounded-2xl p-4 focus:ring-2 focus:ring-blue-500 outline-none text-center text-xl font-bold"
        />
      ),
      disabled: !weight
    },
    {
      title: "Your Height",
      subtitle: "Almost there! (cm)",
      icon: <Ruler size={40} className="text-orange-500" />,
      input: (
        <input
          autoFocus
          type="number"
          value={height}
          onChange={(e) => setHeight(e.target.value)}
          placeholder="Height in cm"
          className="w-full bg-neutral-100 dark:bg-neutral-800 border-none rounded-2xl p-4 focus:ring-2 focus:ring-blue-500 outline-none text-center text-xl font-bold"
        />
      ),
      disabled: !height
    }
  ];

  const currentStepData = steps[step - 1];

  return (
    <div className="fixed inset-0 bg-white dark:bg-neutral-950 z-[90] flex flex-col p-8 transition-colors duration-300">
      <div className="flex-1 flex flex-col items-center justify-center space-y-8 max-w-sm mx-auto">
        <div className="flex gap-2">
          {steps.map((_, i) => (
            <div 
              key={i} 
              className={`h-1.5 w-8 rounded-full transition-colors ${i + 1 <= step ? 'bg-blue-600' : 'bg-neutral-100 dark:bg-neutral-800'}`} 
            />
          ))}
        </div>

        <motion.div
          key={step}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          className="text-center space-y-6 w-full"
        >
          <div className="mx-auto w-20 h-20 bg-neutral-50 dark:bg-neutral-900 rounded-[2rem] flex items-center justify-center shadow-lg shadow-neutral-100 dark:shadow-black/50">
            {currentStepData.icon}
          </div>
          
          <div className="space-y-2">
            <h2 className="text-3xl font-black tracking-tight">{currentStepData.title}</h2>
            <p className="text-neutral-500 font-medium">{currentStepData.subtitle}</p>
          </div>

          <form onSubmit={(e) => { e.preventDefault(); if(!currentStepData.disabled) nextStep(); }}>
            {currentStepData.input}
          </form>
        </motion.div>
      </div>

      <motion.button
        whileTap={{ scale: 0.98 }}
        disabled={currentStepData.disabled}
        onClick={nextStep}
        className={`w-full max-w-sm mx-auto flex items-center justify-center gap-2 py-5 rounded-[2rem] font-bold text-lg shadow-xl transition-all duration-300 ${
          currentStepData.disabled 
            ? 'bg-neutral-100 dark:bg-neutral-800 text-neutral-400' 
            : 'bg-blue-600 text-white shadow-blue-500/20'
        }`}
      >
        {step === 4 ? "Get Started" : "Continue"}
        <ArrowRight size={20} />
      </motion.button>
    </div>
  );
}
