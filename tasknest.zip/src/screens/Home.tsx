import { motion } from 'motion/react';
import { useTasks } from '../hooks/useTasks';
import { useHabits } from '../hooks/useHabits';
import { useUser } from '../hooks/useUser';
import { Calendar, Quote, Droplets, Footprints, StretchHorizontal, Moon } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Home() {
  const { tasksCompletedToday, totalTasks } = useTasks();
  const { habits } = useHabits();
  const { user } = useUser();
  
  const today = new Date();
  const formattedDate = today.toLocaleDateString('en-US', { 
    weekday: 'long', 
    month: 'short', 
    day: 'numeric' 
  });

  const progress = totalTasks > 0 ? (tasksCompletedToday / totalTasks) * 100 : 0;
  const habitsCompleted = habits.filter(h => h.completed).length;

  const suggestions = [
    { icon: <Droplets className="text-blue-500" size={18} />, text: "Drink more water", color: "bg-blue-50 dark:bg-blue-900/20" },
    { icon: <Footprints className="text-green-500" size={18} />, text: "Take a short walk", color: "bg-green-50 dark:bg-green-900/20" },
    { icon: <StretchHorizontal className="text-orange-500" size={18} />, text: "Stretch your body", color: "bg-orange-50 dark:bg-orange-900/20" },
    { icon: <Moon className="text-purple-500" size={18} />, text: "Sleep on time", color: "bg-purple-50 dark:bg-purple-900/20" },
  ];

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="space-y-8"
    >
      {/* Header Section */}
      <section className="pt-4">
        <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
          Hello, {user.name || 'Friend'}
        </h1>
        <div className="flex items-center text-neutral-500 dark:text-neutral-400 mt-1">
          <Calendar size={14} className="mr-1" />
          <p className="text-sm font-medium">{formattedDate}</p>
        </div>
      </section>

      {/* Progress Cards */}
      <section className="grid grid-cols-2 gap-4">
        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="bg-white dark:bg-neutral-900 p-5 rounded-[2rem] border border-neutral-100 dark:border-neutral-800 shadow-sm shadow-blue-500/5"
        >
          <div className="flex flex-col h-full justify-between">
            <span className="text-sm font-semibold text-neutral-400 uppercase tracking-widest">Tasks</span>
            <div className="mt-4 flex items-baseline">
              <span className="text-4xl font-bold">{tasksCompletedToday}</span>
              <span className="text-neutral-400 ml-1">/ {totalTasks}</span>
            </div>
            <div className="mt-4 h-1 w-full bg-neutral-100 dark:bg-neutral-800 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                className="h-full bg-blue-500" 
              />
            </div>
          </div>
        </motion.div>

        <motion.div 
          whileHover={{ scale: 1.02 }}
          className="bg-white dark:bg-neutral-900 p-5 rounded-[2rem] border border-neutral-100 dark:border-neutral-800 shadow-sm shadow-indigo-500/5"
        >
          <div className="flex flex-col h-full justify-between">
            <span className="text-sm font-semibold text-neutral-400 uppercase tracking-widest">Habits</span>
            <div className="mt-4 flex items-baseline">
              <span className="text-4xl font-bold">{habitsCompleted}</span>
              <span className="text-neutral-400 ml-1">/ {habits.length}</span>
            </div>
            <p className="text-xs text-neutral-400 mt-4 italic font-medium">Keep it going!</p>
          </div>
        </motion.div>
      </section>

      {/* Motivational Quote */}
      <section className="bg-gradient-to-br from-blue-600 to-indigo-700 p-6 rounded-[2rem] text-white shadow-xl shadow-blue-500/20 relative overflow-hidden">
        <Quote className="absolute top-4 right-4 opacity-10 text-white" size={64} />
        <p className="text-lg font-medium leading-relaxed relative z-10">
          "The secret of your future is hidden in your daily routine."
        </p>
        <span className="text-sm opacity-60 mt-2 block">— Mike Murdock</span>
      </section>

      {/* Healthy Suggestions */}
      <section className="space-y-4">
        <h2 className="text-xl font-bold px-1">Healthy Suggestions</h2>
        <div className="grid grid-cols-2 gap-3">
          {suggestions.map((s, i) => (
            <motion.div 
              key={i}
              whileTap={{ scale: 0.95 }}
              className={cn("p-4 rounded-3xl flex items-center gap-3 border border-transparent shadow-sm", s.color)}
            >
              {s.icon}
              <span className="text-xs font-semibold leading-tight">{s.text}</span>
            </motion.div>
          ))}
        </div>
      </section>
    </motion.div>
  );
}
