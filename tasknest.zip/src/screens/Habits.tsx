import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useHabits } from '../hooks/useHabits';
import { Plus, X, Flame, Target, Trash2 } from 'lucide-react';
import { cn } from '../lib/utils';

export default function Habits() {
  const { habits, incrementHabit, addHabit, deleteHabit } = useHabits();
  const [isAdding, setIsAdding] = useState(false);
  const [newName, setNewName] = useState('');
  const [newTarget, setNewTarget] = useState(1);
  const [newCategory, setNewCategory] = useState('Personal');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    addHabit(newName, newTarget, newCategory);
    setNewName('');
    setNewTarget(1);
    setIsAdding(false);
  };

  return (
    <div className="pt-4 space-y-6">
      <header className="flex justify-between items-center bg-white/40 dark:bg-neutral-900/40 backdrop-blur-md sticky top-0 py-2 z-10">
        <div>
          <h1 className="text-3xl font-bold">Habit Tracker</h1>
          <p className="text-neutral-500 text-sm font-medium">Build consistency daily</p>
        </div>
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => setIsAdding(true)}
          className="bg-indigo-600 text-white p-3 rounded-2xl shadow-lg shadow-indigo-500/30"
        >
          <Plus size={24} />
        </motion.button>
      </header>

      <div className="grid grid-cols-1 gap-4">
        {habits.map((habit) => (
          <motion.div
            layout
            key={habit.id}
            className={cn(
              "p-5 rounded-[2rem] border transition-all duration-300 relative overflow-hidden group",
              habit.completed 
                ? "bg-green-50 dark:bg-green-900/10 border-green-100 dark:border-green-900" 
                : "bg-white dark:bg-neutral-900 border-neutral-100 dark:border-neutral-800 shadow-sm"
            )}
          >
             <button 
                onClick={() => deleteHabit(habit.id)}
                className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 p-1 text-neutral-300 hover:text-red-500 transition-all"
              >
                <Trash2 size={16} />
              </button>

            <div className="flex justify-between items-start mb-4">
              <div>
                <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-widest bg-neutral-50 dark:bg-neutral-800 px-2 py-0.5 rounded-full">
                  {habit.category}
                </span>
                <h3 className="text-xl font-bold mt-1">{habit.name}</h3>
              </div>
              <div className="flex items-center text-orange-500">
                <Flame size={20} className="mr-1 fill-current" />
                <span className="font-bold text-lg">{habit.current >= habit.target ? "Done" : `${habit.current}/${habit.target}`}</span>
              </div>
            </div>

            <div className="space-y-4">
              <div className="h-2 w-full bg-neutral-100 dark:bg-neutral-800 rounded-full overflow-hidden">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${(habit.current / habit.target) * 100}%` }}
                  className={cn(
                    "h-full transition-colors",
                    habit.completed ? "bg-green-500" : "bg-indigo-500"
                  )}
                />
              </div>

              <div className="flex gap-2">
                 <motion.button
                  whileTap={{ scale: 0.95 }}
                  onClick={() => incrementHabit(habit.id)}
                  disabled={habit.completed}
                  className={cn(
                    "flex-1 font-bold py-3 rounded-2xl transition-all",
                    habit.completed 
                      ? "bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300"
                      : "bg-indigo-600 text-white shadow-lg shadow-indigo-500/20"
                  )}
                >
                  {habit.completed ? "Completed Today" : "Log Progress"}
                </motion.button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      <AnimatePresence>
        {isAdding && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-end justify-center px-4 pb-12 bg-neutral-900/60 backdrop-blur-sm"
          >
            <motion.div 
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              className="w-full max-w-md bg-white dark:bg-neutral-900 rounded-[2.5rem] p-8 space-y-6 shadow-2xl"
            >
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold">New Habit</h2>
                <button onClick={() => setIsAdding(false)} className="p-2 rounded-full bg-neutral-100 dark:bg-neutral-800">
                  <X size={20} />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-bold uppercase text-neutral-400 ml-2">Habit Name</label>
                    <input 
                      autoFocus
                      value={newName}
                      onChange={(e) => setNewName(e.target.value)}
                      placeholder="e.g., Reading"
                      className="w-full bg-neutral-50 dark:bg-neutral-800 border-none rounded-2xl p-4 focus:ring-2 focus:ring-indigo-500 outline-none"
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-bold uppercase text-neutral-400 ml-2 leading-none flex items-center mb-1">
                        Daily Target
                      </label>
                      <div className="flex items-center bg-neutral-50 dark:bg-neutral-800 rounded-2xl px-4 py-2">
                         <button 
                          type="button" 
                          onClick={() => setNewTarget(Math.max(1, newTarget - 1))}
                          className="p-2 hover:text-indigo-600 transition-colors"
                         >-</button>
                         <span className="flex-1 text-center font-bold">{newTarget}</span>
                         <button 
                          type="button"
                          onClick={() => setNewTarget(newTarget + 1)}
                          className="p-2 hover:text-indigo-600 transition-colors"
                         >+</button>
                      </div>
                    </div>
                    <div>
                      <label className="text-xs font-bold uppercase text-neutral-400 ml-2">Category</label>
                      <select 
                        value={newCategory}
                        onChange={(e) => setNewCategory(e.target.value)}
                        className="w-full bg-neutral-50 dark:bg-neutral-800 border-none rounded-2xl p-4 focus:ring-2 focus:ring-indigo-500 outline-none appearance-none font-bold"
                      >
                        {['Health', 'Fitness', 'Mindset', 'Personal'].map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                  </div>
                </div>

                <motion.button
                  whileTap={{ scale: 0.98 }}
                  type="submit"
                  className="w-full bg-indigo-600 text-white font-bold py-4 rounded-2xl shadow-lg shadow-indigo-500/20"
                >
                  Start Habit
                </motion.button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
