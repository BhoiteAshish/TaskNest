import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useTheme } from '../components/ThemeProvider';
import { Sun, Moon, Shield, Info, Trash2, Smartphone, Bell, ChevronRight, User, X } from 'lucide-react';
import { Storage } from '../lib/storage';
import { useUser } from '../hooks/useUser';

export default function Settings() {
  const { theme, toggleTheme } = useTheme();
  const { user, updateProfile } = useUser();
  const [isEditingProfile, setIsEditingProfile] = useState(false);

  const [editName, setEditName] = useState(user.name);
  const [editAge, setEditAge] = useState(user.age);
  const [editWeight, setEditWeight] = useState(user.weight);
  const [editHeight, setEditHeight] = useState(user.height);

  const handleClearData = async () => {
    if (confirm("Are you sure you want to clear all data? This cannot be undone.")) {
      await Storage.clear();
      window.location.reload();
    }
  };

  const handleSaveProfile = (e: React.FormEvent) => {
    e.preventDefault();
    updateProfile({
      name: editName,
      age: editAge,
      weight: editWeight,
      height: editHeight
    });
    setIsEditingProfile(false);
  };

  return (
    <div className="pt-4 space-y-8">
      <header>
        <h1 className="text-3xl font-bold">Settings</h1>
        <p className="text-neutral-500 text-sm font-medium">Personalize your experience</p>
      </header>

      {/* Profile Section */}
      <section 
        onClick={() => setIsEditingProfile(true)}
        className="bg-white dark:bg-neutral-900 p-6 rounded-[2rem] border border-neutral-100 dark:border-neutral-800 shadow-sm flex items-center gap-4 cursor-pointer active:scale-95 transition-transform"
      >
        <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center text-white">
          <User size={32} />
        </div>
        <div>
          <h3 className="text-lg font-bold">{user.name || 'Set Name'}</h3>
          <p className="text-xs text-neutral-400 font-medium">
            {user.age ? `${user.age} yrs` : 'Age not set'} • {user.weight ? `${user.weight}kg` : 'Weight not set'}
          </p>
        </div>
        <button className="ml-auto p-2 text-neutral-400">
          <ChevronRight />
        </button>
      </section>

      <div className="space-y-4">
        <h2 className="text-xs font-bold uppercase tracking-widest text-neutral-400 px-4">Preferences</h2>
        
        <div className="bg-white dark:bg-neutral-900 rounded-[2rem] border border-neutral-100 dark:border-neutral-800 overflow-hidden">
          <SettingItem 
            icon={<Shield size={20} className="text-blue-500" />} 
            label="Privacy" 
          />
          <SettingItem 
            icon={<Bell size={20} className="text-orange-500" />} 
            label="Notifications" 
          />
          <div className="flex items-center justify-between p-5 hover:bg-neutral-50 dark:hover:bg-neutral-800/50 transition-colors border-b border-neutral-100 dark:border-neutral-800 last:border-0">
            <div className="flex items-center gap-4">
              <div className="p-2 rounded-xl bg-neutral-100 dark:bg-neutral-800">
                {theme === 'light' ? <Sun size={20} className="text-yellow-500" /> : <Moon size={20} className="text-purple-500" />}
              </div>
              <span className="font-bold">Dark Mode</span>
            </div>
            <button 
              onClick={toggleTheme}
              className="relative w-12 h-6 rounded-full bg-neutral-200 dark:bg-neutral-700 transition-colors"
            >
              <motion.div 
                animate={{ x: theme === 'dark' ? 24 : 0 }}
                className="absolute top-1 left-1 w-4 h-4 rounded-full bg-white shadow-sm"
              />
            </button>
          </div>
        </div>

        <h2 className="text-xs font-bold uppercase tracking-widest text-neutral-400 px-4 mt-6">App Info</h2>
        <div className="bg-white dark:bg-neutral-900 rounded-[2rem] border border-neutral-100 dark:border-neutral-800 overflow-hidden">
          <SettingItem 
            icon={<Smartphone size={20} className="text-neutral-400" />} 
            label="Version" 
            value="1.0.0"
          />
          <SettingItem 
            icon={<Info size={20} className="text-neutral-400" />} 
            label="About TaskNest" 
          />
          <button 
            onClick={handleClearData}
            className="w-full flex items-center gap-4 p-5 hover:bg-red-50 dark:hover:bg-red-900/10 transition-colors text-red-500"
          >
            <div className="p-2 rounded-xl bg-red-50 dark:bg-red-900/20">
              <Trash2 size={20} />
            </div>
            <span className="font-bold">Clear All Data</span>
          </button>
        </div>
      </div>

      <AnimatePresence>
        {isEditingProfile && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-end justify-center px-4 pb-12 bg-neutral-900/60 backdrop-blur-sm"
          >
            <motion.div 
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              className="w-full max-w-md bg-white dark:bg-neutral-900 rounded-[2.5rem] p-8 space-y-6 shadow-2xl"
            >
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold">Edit Profile</h2>
                <button onClick={() => setIsEditingProfile(false)} className="p-2 rounded-full bg-neutral-100 dark:bg-neutral-800">
                  <X size={20} />
                </button>
              </div>

              <form onSubmit={handleSaveProfile} className="space-y-4">
                <div>
                  <label className="text-xs font-bold uppercase text-neutral-400 ml-2">Name</label>
                  <input 
                    value={editName}
                    onChange={(e) => setEditName(e.target.value)}
                    className="w-full bg-neutral-50 dark:bg-neutral-800 border-none rounded-2xl p-4 focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold uppercase text-neutral-400 ml-2">Age</label>
                    <input 
                      type="number"
                      value={editAge}
                      onChange={(e) => setEditAge(e.target.value)}
                      className="w-full bg-neutral-50 dark:bg-neutral-800 border-none rounded-2xl p-4 focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold uppercase text-neutral-400 ml-2">Weight (kg)</label>
                    <input 
                      type="number"
                      value={editWeight}
                      onChange={(e) => setEditWeight(e.target.value)}
                      className="w-full bg-neutral-50 dark:bg-neutral-800 border-none rounded-2xl p-4 focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-bold uppercase text-neutral-400 ml-2">Height (cm)</label>
                  <input 
                    type="number"
                    value={editHeight}
                    onChange={(e) => setEditHeight(e.target.value)}
                    className="w-full bg-neutral-50 dark:bg-neutral-800 border-none rounded-2xl p-4 focus:ring-2 focus:ring-blue-500 outline-none"
                  />
                </div>

                <motion.button
                  whileTap={{ scale: 0.98 }}
                  type="submit"
                  className="w-full bg-blue-600 text-white font-bold py-4 rounded-2xl shadow-lg shadow-blue-500/20 mt-4"
                >
                  Save Changes
                </motion.button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <p className="text-center text-[10px] text-neutral-400 font-bold uppercase tracking-tighter pb-4">
        Made with ❤️ for Productive Humans
      </p>
    </div>
  );
}

function SettingItem({ icon, label, value }: { icon: React.ReactNode, label: string, value?: string }) {
  return (
    <div className="flex items-center justify-between p-5 hover:bg-neutral-50 dark:hover:bg-neutral-800/50 transition-colors border-b border-neutral-100 dark:border-neutral-800 last:border-0 border-solid cursor-pointer">
      <div className="flex items-center gap-4">
        <div className="p-2 rounded-xl bg-neutral-100 dark:bg-neutral-800">
          {icon}
        </div>
        <span className="font-bold">{label}</span>
      </div>
      {value ? (
        <span className="text-neutral-400 font-bold text-sm">{value}</span>
      ) : (
        <ChevronRight size={18} className="text-neutral-300" />
      )}
    </div>
  )
}
