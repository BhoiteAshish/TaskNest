import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useTasks } from '../hooks/useTasks';
import { Plus, Trash2, Clock, CheckCircle2, Circle, X } from 'lucide-react';
import { Task } from '../types';
import { cn } from '../lib/utils';

export default function Tasks() {
  const { tasks, addTask, toggleTask, deleteTask, allTasksCompleted } = useTasks();
  const [isAdding, setIsAdding] = useState(false);
  const [newTitle, setNewTitle] = useState('');
  const [newTime, setNewTime] = useState('');
  const [newCategory, setNewCategory] = useState<Task['category']>('Personal');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;
    addTask(newTitle, newTime || '--:--', newCategory);
    setNewTitle('');
    setNewTime('');
    setIsAdding(false);
  };

  const categories: Task['category'][] = ['Personal', 'Work', 'Health', 'Other'];

  return (
    <div className="pt-4 space-y-6">
      <header className="flex justify-between items-center bg-white/40 dark:bg-neutral-900/40 backdrop-blur-md sticky top-0 py-2 z-10">
        <div>
          <h1 className="text-3xl font-bold">Today's Tasks</h1>
          <p className="text-neutral-500 text-sm font-medium">{tasks.length} tasks scheduled</p>
        </div>
        <motion.button
          whileTap={{ scale: 0.9 }}
          onClick={() => setIsAdding(true)}
          className="bg-blue-600 text-white p-3 rounded-2xl shadow-lg shadow-blue-500/30"
        >
          <Plus size={24} />
        </motion.button>
      </header>

      {/* Completion Modal */}
      <AnimatePresence>
        {allTasksCompleted && tasks.length > 0 && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.8 }}
            className="bg-green-100 dark:bg-green-900/30 border border-green-200 dark:border-green-800 p-6 rounded-[2rem] text-center"
          >
            <h3 className="text-green-800 dark:text-green-300 font-bold text-xl mb-1">Success! 🎉</h3>
            <p className="text-green-700 dark:text-green-400 text-sm">Today's tasks completed successfully!</p>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="space-y-4">
        {tasks.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-20 text-neutral-400">
            <CheckCircle2 size={64} className="opacity-10 mb-4" />
            <p className="font-medium">All clear! Add a task to start.</p>
          </div>
        ) : (
          tasks.map((task) => (
            <motion.div
              layout
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              key={task.id}
              className={cn(
                "group flex items-center justify-between p-4 rounded-3xl border transition-all duration-300",
                task.completed 
                  ? "bg-neutral-100 dark:bg-neutral-800/50 border-neutral-200 dark:border-neutral-800" 
                  : "bg-white dark:bg-neutral-900 border-neutral-100 dark:border-neutral-800 shadow-sm"
              )}
            >
              <div className="flex items-center gap-4 flex-1">
                <button 
                  onClick={() => toggleTask(task.id)}
                  className={cn(
                    "p-1 rounded-full border-2 transition-colors",
                    task.completed ? "bg-blue-500 border-blue-500 text-white" : "border-neutral-200 dark:border-neutral-700 text-transparent"
                  )}
                >
                  {task.completed ? <CheckCircle2 size={24} /> : <Circle size={24} />}
                </button>
                <div className="flex-1">
                  <h3 className={cn(
                    "font-bold transition-all",
                    task.completed && "line-through text-neutral-400 italic"
                  )}>
                    {task.title}
                  </h3>
                  <div className="flex items-center gap-3 mt-1">
                    <span className="flex items-center text-[10px] font-bold text-neutral-400 uppercase tracking-tighter">
                      <Clock size={10} className="mr-1" /> {task.time}
                    </span>
                    <span className="bg-neutral-50 dark:bg-neutral-800 text-neutral-500 dark:text-neutral-400 text-[10px] px-2 py-0.5 rounded-full font-bold uppercase tracking-tighter">
                      {task.category}
                    </span>
                  </div>
                </div>
              </div>
              <button 
                onClick={() => deleteTask(task.id)}
                className="opacity-0 group-hover:opacity-100 p-2 text-neutral-400 hover:text-red-500 transition-all"
              >
                <Trash2 size={18} />
              </button>
            </motion.div>
          ))
        )}
      </div>

      {/* Add Task Modal overlay */}
      <AnimatePresence>
        {isAdding && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] flex items-end justify-center px-4 pb-12 bg-neutral-900/60 backdrop-blur-sm"
          >
            <motion.div 
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              exit={{ y: "100%" }}
              className="w-full max-w-md bg-white dark:bg-neutral-900 rounded-[2.5rem] p-8 space-y-6 shadow-2xl"
            >
              <div className="flex justify-between items-center">
                <h2 className="text-2xl font-bold">New Task</h2>
                <button onClick={() => setIsAdding(false)} className="p-2 rounded-full bg-neutral-100 dark:bg-neutral-800">
                  <X size={20} />
                </button>
              </div>

              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-bold uppercase text-neutral-400 ml-2">Task Title</label>
                    <input 
                      autoFocus
                      value={newTitle}
                      onChange={(e) => setNewTitle(e.target.value)}
                      placeholder="What needs to be done?"
                      className="w-full bg-neutral-50 dark:bg-neutral-800 border-none rounded-2xl p-4 focus:ring-2 focus:ring-blue-500 outline-none"
                    />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="text-xs font-bold uppercase text-neutral-400 ml-2">Time</label>
                      <input 
                        type="time"
                        value={newTime}
                        onChange={(e) => setNewTime(e.target.value)}
                        className="w-full bg-neutral-50 dark:bg-neutral-800 border-none rounded-2xl p-4 focus:ring-2 focus:ring-blue-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold uppercase text-neutral-400 ml-2">Category</label>
                      <select 
                        value={newCategory}
                        onChange={(e) => setNewCategory(e.target.value as any)}
                        className="w-full bg-neutral-50 dark:bg-neutral-800 border-none rounded-2xl p-4 focus:ring-2 focus:ring-blue-500 outline-none appearance-none font-bold"
                      >
                        {categories.map(c => <option key={c} value={c}>{c}</option>)}
                      </select>
                    </div>
                  </div>
                </div>

                <motion.button
                  whileTap={{ scale: 0.98 }}
                  type="submit"
                  className="w-full bg-blue-600 text-white font-bold py-4 rounded-2xl shadow-lg shadow-blue-500/20"
                >
                  Create Task
                </motion.button>
              </form>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
