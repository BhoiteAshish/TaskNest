export interface Task {
  id: string;
  title: string;
  time: string;
  category: 'Personal' | 'Work' | 'Health' | 'Other';
  completed: boolean;
  createdAt: number;
}

export interface Habit {
  id: string;
  name: string;
  target: number;
  current: number;
  category: string;
  completed: boolean;
}

export type Theme = 'light' | 'dark';

export interface UserProfile {
  name: string;
  age: string;
  weight: string;
  height: string;
  onboarded: boolean;
}
