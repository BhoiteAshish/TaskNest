/**
 * Simple storage utility that mimics AsyncStorage API but uses localStorage.
 */
export const Storage = {
  getItem: async (key: string): Promise<string | null> => {
    try {
      return localStorage.getItem(key);
    } catch (e) {
      console.error('Error reading from storage', e);
      return null;
    }
  },
  setItem: async (key: string, value: string): Promise<void> => {
    try {
      localStorage.setItem(key, value);
    } catch (e) {
      console.error('Error writing to storage', e);
    }
  },
  removeItem: async (key: string): Promise<void> => {
    try {
      localStorage.removeItem(key);
    } catch (e) {
      console.error('Error removing from storage', e);
    }
  },
  clear: async (): Promise<void> => {
    try {
      localStorage.clear();
    } catch (e) {
      console.error('Error clearing storage', e);
    }
  }
};
